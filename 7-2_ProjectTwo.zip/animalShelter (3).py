# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser'
        #PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31135
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print ("Connection Successful")

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.

    def read(self, data):
        if not data:
            cursor = self.collection.find()#finds data
        else:
            cursor = self.collection.find(data)#finds data
            
        result = list(cursor) #converts the cursor object to a list
        return result #returns the list of documents
       

# Create method to implement the U in CRUD
    def update(self, query, data):
        if query and data: #checking if query and data
            result = self.collection.update_many(query, {"$set": data})#update documents that match the query providing the correct date
            return result.modified_count #returns the modified documents amount
        else:
            raise Exception("Invalid query or data")

# Create method to implement the D in CRUD
    def delete(self, query):
        if query:
            result = self.collection.delete_many(query) #deletes documents the match the query
            return result.deleted_count #returns the amount of deleted documents
        else:
            raise Exception("Invalid query")
    